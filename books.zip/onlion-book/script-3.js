function addToCart(bookName) {
  const msg = document.getElementById('cart-message');
  msg.textContent = "${bookName}" 
  msg.style.display = 'block';
  setTimeout(() => {
    msg.style.display = 'none';
  }, 2000);
}
